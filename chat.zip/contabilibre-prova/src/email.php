<?php
    use PHPMailer\PHPMailer\PHPMailer;
    use PHPMailer\PHPMailer\Exception;

    require '../vendor/autoload.php';

    function enviarEmail($emailDestinatario, $nomeDestinatario, $assunto, $mensagem) {
    $mail = new PHPMailer(true);

    try {
        // Configurações do servidor SMTP
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com'; // Ajuste para o servidor do seu email
        $mail->SMTPAuth = true;
        $mail->Username = 'seu_email@gmail.com'; // Seu e-mail
        $mail->Password = 'sua_senha';          // Sua senha
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        // Configurações do e-mail
        $mail->setFrom('seu_email@gmail.com', 'Sistema de Notas');
        $mail->addAddress($emailDestinatario, $nomeDestinatario);
        $mail->Subject = $assunto;
        $mail->Body = $mensagem;

        $mail->send();
        return true;
    } catch (Exception $e) {
        return "Erro ao enviar e-mail: {$mail->ErrorInfo}";
    }
    }
?>