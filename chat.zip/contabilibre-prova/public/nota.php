<?php
    require_once '../src/Nota.php';
    require_once 'email.php';

    $nota = new Nota();

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        if (isset($_POST['acao']) && $_POST['acao'] === 'criar') {
            $id_cliente = $_POST['id_cliente'];
            $numero_nota = $_POST['numero_nota'];
            $data_emissao = $_POST['data_emissao'];
            $valor = $_POST['valor'];

            if ($nota->criar($id_cliente, $numero_nota, $data_emissao,$valor)) {
                // Enviar e-mail para o cliente
                enviarEmail(
                    'cliente_email@example.com', // Use o e-mail do cliente
                    'Cliente Nome',
                    'Nova Nota Fiscal',
                    "Uma nova nota fiscal foi criada no valor de R$ {$valor}."
                );
                echo "Nota criada com sucesso!";
            } else {
            echo "Erro ao criar a nota.";
            }
        }

        // Adicionar lógica para editar e excluir
    }
?>